﻿using System;
using System.Device.Gpio;
using System.Threading;
using System.Xml.Serialization;
using System.Net.Http;
using System.Threading.Tasks;
using System.Security.Cryptography.X509Certificates;



Console.WriteLine("Blinking LED. Press Ctrl+C to end.");

const int pin = 18;
const int pin2 = 23;
using var controller = new GpioController();
controller.OpenPin(pin, PinMode.Output);
controller.OpenPin(pin2, PinMode.Input);



controller.RegisterCallbackForPinValueChangedEvent(
    pin2,
    PinEventTypes.Falling,
    OnPinEvent);

await Task.Delay(Timeout.Infinite);

async void OnPinEvent(object sender, PinValueChangedEventArgs arg)
{
    using(HttpClient client = new HttpClient())
    {
        client.Timeout = TimeSpan.FromSeconds(5);
        try
        {
            string url = "http://172.16.227.15:45456/DingDong";

            HttpResponseMessage response = await client.PostAsync(url, null);

            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                Console.WriteLine("Post has been sent succesfully");
                Blink(1, 1000);
            }
            else
            {
                Blink(7, 500);
            }
        }
        catch (Exception e)
        {
            Console.WriteLine("Error timeout occured");
            Blink(7, 500);
        }
    }
}

void Blink(int count, int delay)
{
    for(int i = 0; i < count; i++)
    {
        controller.Write(pin, PinValue.High);
        Thread.Sleep(delay);
        controller.Write(pin, PinValue.Low);
        Thread.Sleep(delay);
    }
}

