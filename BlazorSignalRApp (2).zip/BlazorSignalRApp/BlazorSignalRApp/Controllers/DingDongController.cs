﻿using BlazorSignalRApp.Hubs;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;


namespace BlazorSignalRApp.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class DingDongController : ControllerBase
    {
        private readonly IHubContext<ChatHub> _context;

        public DingDongController(IHubContext<ChatHub> context)
        {
            _context = context;
        }

        [HttpPost(Name = "PostDingDong")]
        public async Task<IActionResult> Post()
        {
            await _context.Clients.All.SendAsync("ReceiveMessage", "Sonnette", "DING DONG !");
            return Ok();
        }
    }
}
